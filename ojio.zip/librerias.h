#include<iostream>
#include <string.h>
#include <conio.h>
#include <windows.h>
#include <math.h>

using namespace std;
